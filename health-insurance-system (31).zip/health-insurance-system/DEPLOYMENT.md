# Deployment Instructions (Extended)

## ✅ Already Included
- React frontend + Node backend
- SQL database support
- Docker + docker-compose
- Email verification (Gmail/SendGrid)

---

## 🌐 NGINX + HTTPS (Production)

1. Create an SSL certificate (use Let's Encrypt for free):
   ```
   sudo apt install certbot
   sudo certbot certonly --standalone -d yourdomain.com
   ```

2. Update and use the provided `nginx.conf`:
   - Replace `example.com` and cert paths
   - Copy to `/etc/nginx/sites-available/default`
   - Restart nginx: `sudo systemctl restart nginx`

---

## 🚀 Heroku Deployment

1. Create `Procfile` in the root:
   ```
   web: node server/index.js
   ```

2. Set config vars on Heroku:
   - `EMAIL_USER`, `EMAIL_PASS`, `JWT_SECRET`, etc.

3. Push to Heroku:
   ```
   heroku create
   git push heroku main
   ```

---

## ⚡ Vercel Deployment (Frontend Only)

1. Navigate to `/client`, initialize Git and push to GitHub
2. Connect to [Vercel](https://vercel.com) and deploy
3. Set env variables in Vercel dashboard

---

## 🔐 Admin User Roles (Example in Express Middleware)

```js
// middleware/auth.js
exports.isAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    return res.status(403).json({ msg: "Access denied." });
  }
};
```

Usage in routes:
```js
const { isAdmin } = require('./middleware/auth');
router.get("/admin/dashboard", isAdmin, (req, res) => {
  res.send("Welcome admin");
});
```

---

## ⚙ Auto-Loading Environment Variables

Install `dotenv` in backend:

```bash
npm install dotenv
```

Load in `server.js` or `index.js`:

```js
require('dotenv').config();
```

Now all values in `.env` file will auto-load into `process.env`.

---