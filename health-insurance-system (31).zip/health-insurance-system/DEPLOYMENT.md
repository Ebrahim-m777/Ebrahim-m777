# 🛠 Deployment Instructions

## 📦 Prerequisites

- Node.js and npm
- Docker & Docker Compose (optional)
- MySQL Server (or use Docker container)
- Gmail account or SendGrid API key

---

## 🚀 Local Development

1. Install dependencies:
   ```
   cd client
   npm install
   cd ../server
   npm install
   ```

2. Configure environment variables:
   - Copy `.env.example` to `.env`
   - Fill in Gmail credentials or SMTP server

3. Start the servers:
   ```
   cd server && npm run dev
   cd client && npm start
   ```

---

## 🐳 Docker Deployment

1. Place `Dockerfile` and `docker-compose.yml` in root directory.
2. Run:
   ```
   docker-compose up --build
   ```

---

## 📧 Email Service Setup (Gmail or SendGrid)

### Gmail (less secure apps)

```
EMAIL_USER=youremail@gmail.com
EMAIL_PASS=your_app_password  # Create this via Gmail security > App passwords
```

### SendGrid

```
EMAIL_USER=apikey
EMAIL_PASS=your_sendgrid_api_key
```

Update the nodemailer transport in backend:
```js
const transporter = nodemailer.createTransport({
  service: 'gmail', // or 'SendGrid'
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});
```

---

## ✅ Done

You now have a deployable fullstack system with:
- React frontend
- Node.js/Express backend
- SQL database
- Docker support
- Email 2FA + reset